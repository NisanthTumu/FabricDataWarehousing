CREATE TABLE [dbo].[products] (

	[product_id] varchar(max) NULL, 
	[product_name] varchar(max) NULL, 
	[category] varchar(max) NULL, 
	[brand] varchar(max) NULL, 
	[price] float NULL
);