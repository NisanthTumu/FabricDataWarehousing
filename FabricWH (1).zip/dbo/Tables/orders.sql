CREATE TABLE [dbo].[orders] (

	[order_id] varchar(264) NULL, 
	[customer_id] varchar(264) NULL, 
	[product_id] varchar(264) NULL, 
	[order_date] date NULL, 
	[quantity] int NULL, 
	[total_amount] float NULL
);