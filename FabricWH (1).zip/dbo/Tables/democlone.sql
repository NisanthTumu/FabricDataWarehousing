CREATE TABLE [dbo].[democlone] (

	[id] int NULL, 
	[name] varchar(100) NULL
);