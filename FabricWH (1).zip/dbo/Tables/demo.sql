CREATE TABLE [dbo].[demo] (

	[id] int NULL, 
	[name] varchar(100) NULL
);