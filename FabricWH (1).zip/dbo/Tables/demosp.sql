CREATE TABLE [dbo].[demosp] (

	[id] int NULL, 
	[name] varchar(100) NULL
);