CREATE TABLE [dbo].[demo1] (

	[id] int NULL
);