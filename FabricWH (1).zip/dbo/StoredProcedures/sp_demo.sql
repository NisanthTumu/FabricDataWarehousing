create PROCEDURE dbo.sp_demo
AS
    BEGIN

    Drop table IF EXISTS dbo.demosp;

    CREATE table dbo.demosp
    (id INT,
    name varchar(100));
    INSERT into dbo.demosp
    VALUES (1,'sp');

    END;