-- Auto Generated (Do not modify) 89393FF1DAE50704A01F5AC742D0EFF1D8BE3373ABD75B9FFCE5D641DCE2D053
CREATE VIEW [silver].[orders] AS (select [_].[order_id] as [order_id],
    [_].[customer_id] as [customer_id],
    [_].[product_id] as [product_id],
    [_].[order_date] as [order_date],
    [_].[quantity] as [quantity],
    [_].[total_amount] as [price],
    [_].[quantity] * [_].[total_amount] as [amount]
from [FabricWH].[dbo].[orders] as [_])