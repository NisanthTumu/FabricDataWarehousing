-- Auto Generated (Do not modify) B84ED1094608095A6B3899A3453260441118B09E7541771651C2FEFAE42F391B
CREATE VIEW [silver].[regions] AS (select [_].[region_id] as [region_id],
    upper([_].[region]) as [region]
from [FabricWH].[dbo].[regions] as [_])