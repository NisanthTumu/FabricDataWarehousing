-- Auto Generated (Do not modify) 4AFB7AD0CF62E713B66B40408232D16AA322AE11B6574A93AFB77321E65E71EF
CREATE VIEW [silver].[products] AS (select [_].[product_id] as [product_id],
    upper([_].[product_name]) as [product_name],
    [_].[category] as [category],
    [_].[brand] as [brand],
    [_].[price] as [price],
    (case
        when [_].[category] is not null
        then [_].[category]
        else ''
    end) + ((case
        when [_].[category] is not null and [_].[brand] is not null
        then '-'
        else ''
    end) + (case
        when [_].[brand] is not null
        then [_].[brand]
        else ''
    end)) as [details]
from [FabricWH].[dbo].[products] as [_])