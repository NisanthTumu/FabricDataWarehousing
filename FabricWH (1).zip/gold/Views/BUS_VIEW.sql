-- Auto Generated (Do not modify) 132E0A60FD8C7819B45D39B63104A6FB76D7F45C0D755348ACF0D886E8918ADD
CREATE VIEW gold.BUS_VIEW
AS

WITH cat_sales AS
(
select o.order_id,p.product_name,p.price,o.quantity,p.category,o.amount
from silver.orders o left JOIN silver.products p on o.product_id = p.product_id
),
cat_sales2 AS
(
select o.order_id,p.product_name,p.price,o.quantity,p.category,o.amount
from silver.orders o left JOIN silver.products p on o.product_id = p.product_id
),
PARENT AS(
SELECT category,
count(order_id) as total_orders
from cat_sales
group by category)

select *,
DENSE_RANK() over (ORDER BY total_orders ASC) as RANK
from PARENT