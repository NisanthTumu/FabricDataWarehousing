CREATE TABLE [gold].[regions] (

	[region_id] varchar(8000) NULL, 
	[region] varchar(8000) NULL
);